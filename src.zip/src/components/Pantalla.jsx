import React from "react";
import './Pantalla.css';

const Pantalla = ({ input }) => (
    <div className="input">
        {input}
    </div>
);

export default Pantalla;
