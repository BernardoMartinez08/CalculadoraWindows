import React from "react";
import './PantallaSecundaria.css'

const PantallaSecundaria = ({ result }) => (
    <div className="result">
        {result}
    </div>
);

export default PantallaSecundaria;
